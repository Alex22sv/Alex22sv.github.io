@ECHO OFF
start javaw -jar Elektro.jar