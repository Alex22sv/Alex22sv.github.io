#!/bin/bash
java -jar Elektro.jar