# Elektro I: You Can (Not) Redo
Elektro I is a videogame inspired on the book "Electro" by Javier Ruescas and Manu Carbajo.

## How to play
In order to play Elektro I, you must install [Java 21](https://www.oracle.com/java/technologies/downloads/#java21) to play the game.
1. Download the ZIP file from our website: [here](https://alex22sv.github.io/elektro.html#download)
2. Extract the files.
4. For Linux: Right click the "run.sh" file and click "Run as a program".
5. For Windows: Right click the "run.bash" file and click "Run as a program".
6. A terminal should appear displaying the game FPS and then a new game window will load.
7. Keep in mind that it could take a couple of seconds before the game displays anything on the window.
